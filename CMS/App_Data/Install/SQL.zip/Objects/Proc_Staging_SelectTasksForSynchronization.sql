SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [Proc_Staging_SelectTasksForSynchronization]
@TaskIDs Type_CMS_OrderedIntegerTable readonly,
@ServerId int
AS
BEGIN
SET NOCOUNT ON;

WITH tasks AS
(
    -- Select old document tasks that needs to be processed before the requested tasks 
	SELECT Old.* FROM Staging_Task AS Old 
	JOIN Staging_Task AS New 
	ON Old.TaskDocumentID = New.TaskDocumentID AND Old.TaskNodeID = New.TaskNodeID AND Old.TaskID < New.TaskID
	WHERE New.TaskID IN (SELECT * FROM @TaskIDs)

	UNION ALL

    -- Select old object tasks that needs to be processed before the requested tasks 
	SELECT Old.* FROM Staging_Task AS Old
	JOIN Staging_Task AS New 
	ON Old.TaskObjectID = New.TaskObjectID AND Old.TaskObjectType = New.TaskObjectType AND ((Old.TaskSiteID IS NULL AND New.TaskSiteID IS NULL) OR Old.TaskSiteID = New.TaskSiteID) AND Old.TaskID < New.TaskID
	WHERE New.TaskID IN (SELECT * FROM @TaskIDs)

	UNION

    -- Select requested tasks that needs to be processed before the requested tasks 
	SELECT * FROM Staging_Task
	WHERE TaskID IN (SELECT * FROM @TaskIDs)
)
SELECT * FROM tasks
-- Filter tasks for given server
WHERE @ServerId <= 0 OR TaskID IN (SELECT SynchronizationTaskID FROM Staging_Synchronization WHERE SynchronizationServerID = @ServerId)
ORDER BY TaskID
END


GO
